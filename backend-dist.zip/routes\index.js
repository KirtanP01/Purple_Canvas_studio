import { Router } from 'express';
import { IndexController, UserController, BookingController, ContactController } from '../controllers/index.js';
import { BirthdayPartyController } from '../controllers/birthdayParty.js';
import { PaintingPartyController } from '../controllers/paintingParty.js';
import { ArtClassController } from '../controllers/artClass.js';
import { PaymentController } from '../controllers/payment.js';
const router = Router();
const indexController = new IndexController();
const birthdayPartyController = new BirthdayPartyController();
const paintingPartyController = new PaintingPartyController();
const artClassController = new ArtClassController();
const paymentController = new PaymentController();
const userController = new UserController();
const bookingController = new BookingController();
const contactController = new ContactController();
export function setRoutes(app) {
    app.use('/api', router);
    // API info
    router.get('/', indexController.getExample);
    // Birthday Parties CRUD
    router.post('/birthday-parties', birthdayPartyController.create);
    router.get('/birthday-parties', birthdayPartyController.getAll);
    router.get('/birthday-parties/:id', birthdayPartyController.getById);
    router.put('/birthday-parties/:id', birthdayPartyController.update);
    router.delete('/birthday-parties/:id', birthdayPartyController.delete);
    router.post('/birthday-parties/:id/payment', birthdayPartyController.updatePayment.bind(birthdayPartyController));
    // Painting Parties CRUD
    router.post('/painting-parties', paintingPartyController.create);
    router.get('/painting-parties', paintingPartyController.getAll);
    router.get('/painting-parties/:id', paintingPartyController.getById);
    router.put('/painting-parties/:id', paintingPartyController.update);
    router.delete('/painting-parties/:id', paintingPartyController.delete);
    router.post('/painting-parties/:id/payment', paintingPartyController.updatePayment.bind(paintingPartyController));
    // Art Classes CRUD
    router.post('/art-classes', artClassController.create);
    router.get('/art-classes', artClassController.getAll);
    router.get('/art-classes/:id', artClassController.getById);
    router.put('/art-classes/:id', artClassController.update);
    router.delete('/art-classes/:id', artClassController.delete);
    router.post('/art-classes/:id/payment', artClassController.updatePayment.bind(artClassController));
    // PayPal Payment endpoints
    router.post('/payments/create-order', paymentController.createOrder.bind(paymentController));
    router.post('/payments/capture-order', paymentController.captureOrder.bind(paymentController));
    router.get('/payments/order/:orderID', paymentController.getOrder.bind(paymentController));
}
