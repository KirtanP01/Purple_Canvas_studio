import { UserModel, BookingModel, ContactMessageModel } from '../models/index.js';
export class IndexController {
    async getExample(req, res) {
        try {
            res.status(200).json({
                message: "Purple Canvas Studio API is running!",
                version: "1.0.0",
                endpoints: [
                    "GET /api - API info",
                    "POST /api/users - Create user",
                    "POST /api/bookings - Create booking",
                    "GET /api/bookings - Get all bookings",
                    "POST /api/contact - Send contact message"
                ]
            });
        }
        catch (error) {
            res.status(500).json({ error: "An error occurred" });
        }
    }
}
export class UserController {
    async createUser(req, res) {
        try {
            const { email, name, password, role, phone } = req.body;
            if (!email || !name || !password || !role) {
                return res.status(400).json({ error: "Email, name, password, and role are required" });
            }
            // Check if user already exists
            const existingUser = await UserModel.findByEmail(email);
            if (existingUser) {
                return res.status(409).json({ error: "User with this email already exists" });
            }
            // Hash password
            const bcrypt = require('bcrypt');
            const saltRounds = 10;
            const hashedPassword = await bcrypt.hash(password, saltRounds);
            const user = await UserModel.create({ email, name, password: hashedPassword, role, phone });
            res.status(201).json({ message: "User created successfully", user });
        }
        catch (error) {
            console.error('Error creating user:', error);
            res.status(500).json({ error: "Failed to create user" });
        }
    }
    async login(req, res) {
        try {
            const { email, password } = req.body;
            if (!email || !password) {
                return res.status(400).json({ error: "Email and password are required" });
            }
            const user = await UserModel.findByEmail(email);
            if (!user) {
                return res.status(401).json({ error: "Invalid credentials" });
            }
            const bcrypt = require('bcrypt');
            const valid = await bcrypt.compare(password, user.password);
            if (!valid) {
                return res.status(401).json({ error: "Invalid credentials" });
            }
            // For demo: return user info (in production, use JWT)
            res.status(200).json({ message: "Login successful", user });
        }
        catch (error) {
            console.error('Error logging in:', error);
            res.status(500).json({ error: "Failed to login" });
        }
    }
    async getAllUsers(req, res) {
        try {
            // In production, check admin role here
            const users = await UserModel.findAll();
            res.status(200).json({ users });
        }
        catch (error) {
            console.error('Error fetching users:', error);
            res.status(500).json({ error: "Failed to fetch users" });
        }
    }
    async getUser(req, res) {
        try {
            const { id } = req.params;
            const user = await UserModel.findById(parseInt(id));
            if (!user) {
                return res.status(404).json({ error: "User not found" });
            }
            res.status(200).json({ user });
        }
        catch (error) {
            console.error('Error fetching user:', error);
            res.status(500).json({ error: "Failed to fetch user" });
        }
    }
}
export class BookingController {
    async createBooking(req, res) {
        try {
            const { user_id, activity_type, date, participants, special_requests } = req.body;
            if (!user_id || !activity_type || !date || !participants) {
                return res.status(400).json({
                    error: "User ID, activity type, date, and participants are required"
                });
            }
            // Validate activity type
            const validActivities = ['painting-parties', 'birthday-parties', 'art-classes'];
            if (!validActivities.includes(activity_type)) {
                return res.status(400).json({
                    error: "Invalid activity type. Must be one of: " + validActivities.join(', ')
                });
            }
            const booking = await BookingModel.create({
                user_id,
                activity_type,
                date: new Date(date),
                participants,
                special_requests,
                status: 'pending'
            });
            res.status(201).json({ message: "Booking created successfully", booking });
        }
        catch (error) {
            console.error('Error creating booking:', error);
            res.status(500).json({ error: "Failed to create booking" });
        }
    }
    async getAllBookings(req, res) {
        try {
            const bookings = await BookingModel.findAll();
            res.status(200).json({ bookings });
        }
        catch (error) {
            console.error('Error fetching bookings:', error);
            res.status(500).json({ error: "Failed to fetch bookings" });
        }
    }
    async getUserBookings(req, res) {
        try {
            const { userId } = req.params;
            const bookings = await BookingModel.findByUserId(parseInt(userId));
            res.status(200).json({ bookings });
        }
        catch (error) {
            console.error('Error fetching user bookings:', error);
            res.status(500).json({ error: "Failed to fetch user bookings" });
        }
    }
    async updateBookingStatus(req, res) {
        try {
            const { id } = req.params;
            const { status } = req.body;
            const validStatuses = ['pending', 'confirmed', 'completed', 'cancelled'];
            if (!validStatuses.includes(status)) {
                return res.status(400).json({
                    error: "Invalid status. Must be one of: " + validStatuses.join(', ')
                });
            }
            const booking = await BookingModel.updateStatus(parseInt(id), status);
            if (!booking) {
                return res.status(404).json({ error: "Booking not found" });
            }
            res.status(200).json({ message: "Booking status updated", booking });
        }
        catch (error) {
            console.error('Error updating booking status:', error);
            res.status(500).json({ error: "Failed to update booking status" });
        }
    }
}
export class ContactController {
    async createMessage(req, res) {
        try {
            const { name, email, subject, message } = req.body;
            if (!name || !email || !message) {
                return res.status(400).json({ error: "Name, email, and message are required" });
            }
            const contactMessage = await ContactMessageModel.create({
                name,
                email,
                subject,
                message
            });
            res.status(201).json({
                message: "Contact message sent successfully",
                contactMessage
            });
        }
        catch (error) {
            console.error('Error creating contact message:', error);
            res.status(500).json({ error: "Failed to send contact message" });
        }
    }
    async getAllMessages(req, res) {
        try {
            const messages = await ContactMessageModel.findAll();
            res.status(200).json({ messages });
        }
        catch (error) {
            console.error('Error fetching contact messages:', error);
            res.status(500).json({ error: "Failed to fetch contact messages" });
        }
    }
}
