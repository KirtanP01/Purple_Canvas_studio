import { pool } from '../db/index.js';
export class PaintingPartyModel {
    static async create(data) {
        const query = `
            INSERT INTO painting_parties (
                parent_name, email, phone, party_date, party_time, 
                guest_count, child_age, theme, custom_theme, 
                venue_address, city, zip_code, special_requests, status
            )
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
            RETURNING *;
        `;
        const values = [
            data.parentName || '',
            data.email || '',
            data.phone || '',
            data.partyDate || new Date().toISOString().split('T')[0],
            data.partyTime || '00:00',
            data.guestCount || 6,
            data.childAge || '',
            data.theme || '',
            data.customTheme || null,
            data.venueAddress || '',
            data.city || '',
            data.zipCode || '',
            data.specialRequests || null,
            data.status || 'pending'
        ];
        console.log('Preparing to execute SQL for painting party:', query, values);
        try {
            const result = await pool.query(query, values);
            console.log('SQL execution result:', result);
            return result.rows[0];
        }
        catch (error) {
            console.error('Error in PaintingPartyModel.create:', error);
            if (error instanceof Error) {
                console.error(error.stack);
            }
            throw error;
        }
    }
    static async findAll() {
        const result = await pool.query('SELECT * FROM painting_parties ORDER BY date DESC');
        return result.rows;
    }
    static async findById(id) {
        const result = await pool.query('SELECT * FROM painting_parties WHERE id = $1', [id]);
        return result.rows[0] || null;
    }
    static async update(id, data) {
        const fields = [];
        const values = [];
        let idx = 1;
        for (const key in data) {
            fields.push(`${key} = $${idx}`);
            values.push(data[key]);
            idx++;
        }
        if (fields.length === 0)
            return null;
        values.push(id);
        const query = `UPDATE painting_parties SET ${fields.join(', ')} WHERE id = $${idx} RETURNING *;`;
        const result = await pool.query(query, values);
        return result.rows[0] || null;
    }
    static async delete(id) {
        const result = await pool.query('DELETE FROM painting_parties WHERE id = $1', [id]);
        return !!result.rowCount;
    }
}
